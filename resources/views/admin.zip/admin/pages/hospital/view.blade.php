@extends('admin.layouts.app')  
    @section('content')
        <!-- BEGIN CONTENT BODY -->
        <div class="page-content">
                    
                    <div class="row">
                        <div class="col-md-12">
                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet light ">
                                <div class="portlet-title">
                                    <div class="caption font-dark">
                                        <i class="icon-settings font-dark"></i>
                                        <span class="caption-subject bold uppercase"> Hospital Table</span>
                                    </div>
                                    <div>
                                                <div class="btn-group pull-right">
                                                    <button class="btn green  btn-outline dropdown-toggle" data-toggle="dropdown">Tools
                                                        <i class="fa fa-angle-down"></i>
                                                    </button>
                                                    <ul class="dropdown-menu pull-right">
                                                        <li>
                                                            <a href="javascript:;">
                                                                <i class="fa fa-print"></i> Print </a>
                                                        </li>
                                                        <li>
                                                            <a href="javascript:;">
                                                                <i class="fa fa-file-pdf-o"></i> Save as PDF </a>
                                                        </li>
                                                        <li>
                                                            <a href="javascript:;">
                                                                <i class="fa fa-file-excel-o"></i> Export to Excel </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                </div>
                                    <table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
                                        <thead>
                                            <tr>
                                                <th>
                                                    <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                                        <input type="checkbox" class="group-checkable" data-set="#sample_1 .checkboxes" />
                                                        <span></span>
                                                    </label>
                                                </th>
                                                <th>LOGO</th>
                                                <th>ID</th>
                                                <th>City</th>
                                                <th>User ID</th>
                                                <th>Name</th>
                                                <th>Email</th>
                                                <th>Contact No.</th>
                                                <th>Address</th>
                                                <th>Password</th>
                                                <th>Contact Person's Name</th>
                                                <th>Contact Person's Mobile No.</th>
                                                <th>Description</th>
                                                <th>Status</th>
                                                <th>Actions</th>
                                                <th>Images</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($hospital as $hospital)
                                            <tr class="odd gradeX">
                                                <td>
                                                    <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                                        <input type="checkbox" class="checkboxes" value="1" />
                                                        <span></span>
                                                    </label>
                                                </td>
                                                <td><img src="{{asset('/images/hospital/logo/'.$hospital->image)}}" height="100" width="100"></td>
                                                <td>{{$hospital->id}} </td>
                                                <td>{{$hospital->cities->city}} </td>
                                                <td>{{$hospital->user_id}} </td>
                                                <td>{{$hospital->name}} </td>
                                                <td>{{$hospital->email}} </td>
                                                <td>{{$hospital->contact_no}} </td>
                                                <td>{{$hospital->address}} </td>
                                                <td>{{$hospital->password}} </td>
                                                <td>{{$hospital->contact_person_name}} </td>
                                                <td>{{$hospital->contact_person_mobile_no}} </td>
                                                <td>{!!$hospital->description!!} </td>
                                                <td>{{$hospital->status}} </td>
                                                <td>
                                                    <a href="{{route('deletehospital',['id'=>$hospital->id])}}" onclick="return confirm('Do You Really Want To Delete This Hospital?')">
                                                        <button type="button" class="btn btn-outline red btn-sm">
                                                            <i class="fa fa-trash-o"></i>
                                                        </button>
                                                    </a>
                                                    <a href="{{route('edithospital',['id'=>$hospital->id])}}">
                                                        <button type="button" class="btn btn-outline green btn-sm">
                                                            <i class="fa fa-pencil"></i>
                                                        </button>
                                                    </a>
                                                </td>
                                                <td>
                                                    <a href="{{route('viewimage',['id'=>$hospital->id])}}">
                                                        <button class="btn btn-outline blue btn-sm">
                                                            <i class="fa fa-image"></i>
                                                        </button>
                                                    </a>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <!-- END EXAMPLE TABLE PORTLET-->
                    </div>
                </div>
             </div>
        <!-- END CONTENT BODY -->
    @endsection