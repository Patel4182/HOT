<h1>Thanks for registration</h1>

<p>Welcome to organTrasplant </p>

<p>Dr. {{$name}}</p>

<p>Your Email is : {{$email}} </p>
