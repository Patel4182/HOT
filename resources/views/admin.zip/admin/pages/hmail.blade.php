<h1>Thanks for registration</h1>

<p>Welcome to organTrasplant </p>

<p>Use below creatials for login</p>

<p>Email : {{$email}} </p>

<p>Password : {{$password}} </p>