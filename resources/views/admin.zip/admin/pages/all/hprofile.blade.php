@extends('admin.layouts.app')  
@section('content')

<div class="page-content">
                   
                    <h3 class="page-title"> Hospital Profile </h3>
                   
                    <div class="profile">
                        <div class="tabbable-line tabbable-full-width">
                            <ul class="nav nav-tabs">
                                <li class="active">
                                    <a href="#tab_1_1" data-toggle="tab"> Overview </a>
                                </li>
                                <li>
                                    <a href="#tab_1_3" data-toggle="tab"> Account </a>
                                </li>
                                <li>
                                    <a href="#tab_1_6" data-toggle="tab"> Help </a>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane active" id="tab_1_1">
                                    <div class="row">
                                    @foreach($hospital as $hospital)
                                        <div class="col-md-3">
                                            <ul class="list-unstyled profile-nav">
                                                <li>
                                                    <img src="{{asset('/images/hospital/logo/'.$hospital->image)}}" class="img-responsive pic-bordered" alt="" />
                                                    <a href="javascript:;" class="profile-edit"> edit </a>
                                                </li>
                                                <li>
                                                    <a href="javascript:;"> Projects </a>
                                                </li>
                                                <li>
                                                    <a href="javascript:;"> Messages
                                                        <span> 3 </span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="javascript:;"> Friends </a>
                                                </li>
                                                <li>
                                                    <a href="javascript:;"> Settings </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="col-md-9">
                                            <div class="row">
                                                <div class="col-md-8 profile-info">
                                                    <h1 class="font-green sbold uppercase">{{$hospital->name}}</h1>
                                                    <p> {{$hospital->description}} </p>
                                                   
                                                    <ul class="list-inline">
                                                        <li>
                                                            <i class="fa fa-map-marker"></i>{{$hospital->cities->city}}</li>
                                                            <li>
                                                            <i class="fa fa-map-marker"></i>{{$hospital->email}} </li>
                                                            <li>
                                                            <i class="fa fa-map-marker"></i>{{$hospital->contact_no}} </li>
                                                            <li>
                                                            <i class="fa fa-map-marker"></i>{{$hospital->address}} </li>

                                                        
                                                    </ul>
                                                </div>
                                                <!--end col-md-8-->
                                               
                                                <!--end col-md-4-->
                                            </div>
                                            <!--end row-->
                                           
                                        </div>
                                    @endforeach
                                    </div>
                                </div>
                               
                                <!--end tab-pane-->
                               
                                <!--end tab-pane-->
                            </div>
                        </div>
                    </div>
                </div>
            <a href="javascript:;" class="page-quick-sidebar-toggler">
                <i class="icon-login"></i>
            </a>
           
        </div>   
@endsection