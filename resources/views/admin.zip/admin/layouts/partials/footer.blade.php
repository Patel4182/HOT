<!-- BEGIN FOOTER -->
<div class="page-footer"  style="margin-left:500px;">
            <div class="page-footer-inner"> 
                <p>Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | <i class="icon-heart" aria-hidden="true"></i> by <a href="" target="_blank">Organ Transplant</a>
                <!-- <a href="#" title="Purchase Metronic just for 27$ and get lifetime updates for free" target="_blank"></a> -->
            </div>
            <div class="scroll-to-top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>
        <!-- END FOOTER -->